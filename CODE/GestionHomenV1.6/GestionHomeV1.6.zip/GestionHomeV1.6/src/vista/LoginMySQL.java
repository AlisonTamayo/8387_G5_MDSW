package vista;


public class LoginMySQL {

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
    
}
